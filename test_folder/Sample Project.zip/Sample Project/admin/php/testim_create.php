<?php

// Include config file
require_once "../../dbconn.php";

// Define variables and initialize with empty values
$test_name = $test_desc = "";
$test_name_err = $test_desc_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate that each of the free text entry fields are populated
        $input_test_name = trim($_POST["test_name"]);
        if(empty($input_test_name)){
            $test_name_err = "Please enter the customers name.";     
        } else{
            $test_name = $input_test_name;
        }
        $input_test_desc = trim($_POST["test_desc"]);
        if(empty($input_test_desc)){
            $test_desc_err = "Please enter the testimonial statement.";     
        } else{
            $test_desc = $input_test_desc;
        }

// Check input errors before inserting in database
if(empty($test_name_err) && empty($test_desc_err)){
    // Prepare the insert statement
    $sql = "INSERT INTO testimonial (test_name, test_desc) VALUES (?,?);";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_test_name, $param_test_desc); 
            

            $param_test_name = $test_name;
            $param_test_desc = $test_desc;

            //define values selected from drop down lists and checkbox
            //$param_test_name = $_POST['test_name'];
            //$param_test_desc = $_POST['test_desc'];

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: testim.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <title>Admin Users</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
 <!-- <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">-->

  <link rel="stylesheet" href="../../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/jquery-ui.css">
  <link rel="stylesheet" href="../../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../../css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
<header class="site-navbar site-navbar-target" role="banner">

<div class="container">
    <div class="row align-items-center position-relative">

      <div class="col-lg-5">
        <nav class="site-navigation text-right ml-auto" role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li><a href="a_cakes.php" class="nav-link">Cakes</a></li>
            <li class="active"><a href="testim.php" class="nav-link">Testimonials</a></li>
          </ul>
        </nav>
      </div>

      <div class="col-lg-2 text-center">
        <div class="site-logo">
          <a href="../index.php" class="site-logo">
            <img src="../../images/logo.png" alt="Image" class="img-fluid">
          </a>
        </div>
      </div>

      <div class="col-lg-5">
        <nav class="site-navigation text-left mr-auto " role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li><a href="coinfo.php?id=1" class="nav-link">Company Info</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="logout.php" type="submit" class="btn btn-warning" style="width: 100px">Logout</a></li>
          </ul>
        </nav>
      </div>
      

    </div>
  </div>

</header>

    <div class="admin container">
     
              <div class="row admin-p" style="padding-top:20px">
                <div class="col-2"></div>
                <div class="col-6">
                <?php
                session_start();
                // check if the user logged in is admin
                if(isset($_SESSION["loggedin"]) === true){
                ?>
                <h2>Create Testimonial</h2></div>
                <?php
                }
                else {
                  //Redirect to login page
                  header("location: ../index.php");
                }
                ?>
                <div class="col-2">
                <a href="testim.php" class="btn btn-warning" style="float:right">Back to List</a>
                </div>
                <div class="col-2"></div>
            </div>
          <br>
          <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
                    <div class="form-group <?php echo (!empty($test_name_err)) ? 'has-error' : ''; ?>">
                        <label>Customers Name</label>
                        <input type="text" name="test_name" class="form-control" style="width: 300px"value="<?php echo $test_name; ?>">
                        <span class="help-block"><?php echo $test_name_err; ?></span>
                    </div> 
                    <div class="form-group <?php echo (!empty($test_desc_err)) ? 'has-error' : ''; ?>">
                        <label>Customers Testimonial</label>
                        <textarea name="test_desc" rows="4" class="form-control" value="<?php echo $test_desc; ?>"></textarea>
                        <span class="help-block"><?php echo $test_desc_err; ?></span>
                    </div>       
                    <br>
                    <div class="form-group">
                        <input type="submit" class="btn btn-success" value="Create Entry">
                    </div>
                </form>
                <br>
                </div>
                <div class="col-2"></div>
          </div>
        </div>
     

    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../../js/jquery-3.3.1.min.js"></script>
  <script src="../../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../../js/jquery-ui.js"></script>
  <script src="../../js/popper.min.js"></script>
  <script src="../../js/bootstrap.min.js"></script>
  <script src="../../js/owl.carousel.min.js"></script>
  <script src="../../js/jquery.stellar.min.js"></script>
  <script src="../../js/jquery.countdown.min.js"></script>
  <script src="../../js/bootstrap-datepicker.min.js"></script>
  <script src="../../js/jquery.easing.1.3.js"></script>
  <script src="../../js/aos.js"></script>
  <script src="../../js/jquery.fancybox.min.js"></script>
  <script src="../../js/jquery.sticky.js"></script>
  <script src="../../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../../js/main.js"></script>

</body>

</html>