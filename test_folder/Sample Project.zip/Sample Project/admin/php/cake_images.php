<?php

// Include config file
require_once "../../dbconn.php";

// Get id from URL 
$cake_id = $_GET['id'];

// Get values from database
$sql = "SELECT * FROM
        cake_info
        WHERE
        cake_info.cake_id='$cake_id'";

        $result = mysqli_query($link, $sql);
        while($row = mysqli_fetch_array($result)){
            $cake_id = $row['cake_id'];  
            $cake_name = $row['cake_name'];  
        }

    if(isset($_POST["insert"]))
    {
    //if insert button selected
    $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
    $sql = "INSERT INTO images(name) VALUES ('$file')";

    if(mysqli_query($link, $sql))
    {
        echo '<script>alert("Image Inserted into Database")</script>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <title>Manage Images</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
 <!-- <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">-->

  <link rel="stylesheet" href="../../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/jquery-ui.css">
  <link rel="stylesheet" href="../../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../../css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
<header class="site-navbar site-navbar-target" role="banner">

<div class="container">
    <div class="row align-items-center position-relative">

      <div class="col-lg-5">
        <nav class="site-navigation text-right ml-auto" role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li class="active"><a href="a_cakes.php" class="nav-link">Cakes</a></li>
            <li><a href="testim.php" class="nav-link">Testimonials</a></li>
          </ul>
        </nav>
      </div>

      <div class="col-lg-2 text-center">
        <div class="site-logo">
          <a href="../index.php" class="site-logo">
            <img src="../../images/logo.png" alt="Image" class="img-fluid">
          </a>
        </div>
      </div>

      <div class="col-lg-5">
        <nav class="site-navigation text-left mr-auto " role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li><a href="coinfo.php?id=1" class="nav-link">Company Info</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="logout.php" type="submit" class="btn btn-warning" style="width: 100px">Logout</a></li>
          </ul>
        </nav>
      </div>
      
      <div class="ml-auto py-md-3 px-md-3 py-sm-3 px-sm-4 toggle-button d-inline-block d-lg-none">
        <a href="#" class="site-menu-toggle js-menu-toggle text-black">
        <span class="icon-menu" style="font-size:80px;"></span></a>
          </div>
          
    </div>
  </div>

</header>

    <div class="admin container">
      
              <div class="row admin-p" style="padding-top:20px">
                <div class="col-3"></div>
                <div class="col-5">
                <?php
                session_start();
                // check if the user logged in is admin
                if(isset($_SESSION["loggedin"]) === true){
                ?>
                <h2>Upload Images</h2></div>
                <?php
                }
                else {
                  //Redirect to login page
                  header("location: ../index.php");
                }
                ?>
                <div class="col-2">
                <a href="a_cakes.php" class="btn btn-warning" style="float:right">Back to List</a>
                </div>
                <div class="col-2"></div>
            </div>
          <br>
          <div class="row">
                <div class="col-3"></div>
                <div class="col-6">
                <p><?php echo "Cake Ref # ".$cake_id.": ".$cake_name;?></p><br>
                <form action="image_upload.php?id=<?php echo $cake_id ?>" method="post" enctype="multipart/form-data">
                    <input type="file" name="fileToUpload" id="fileToUpload">
                    <input type="submit" value="Upload Image" name="submit">
                    </form>
                </div>
                <div class="col-3"></div>
          </div>
          <div class="row">
                <div class="col-3"></div>
                <div class="col-6">
                    <table class="table table-borderless">
                    <tr>
                        <br>
                    <th>Images loaded:</th>
                    </tr>
                        <?php
                            $sql = "SELECT * FROM images";
                            $result = mysqli_query($link,$sql);
                            while($row = mysqli_fetch_array($result)){
                            if($row['cake_id']==$cake_id){
                        ?>
                    <tr>
                        <td width="40%"> 
                        <img style="margin:5px" width="200" src="../../images/<?php echo $row['img_name'];?>">
                        </td>
                        <td width="60%"><br><br><br>
                        <?php echo $row['img_name'];?>
                        <form action="image_delete.php?id=<?php echo $cake_id ?>&imageid=<?php echo $row['img_name'];?>" method="post">
                            <input name="delete_file" type="hidden" value="<?php echo $row['img_name'];?>">
                            <input type="submit" value="Delete Image" style="float:left" name="fileToDelete" id="fileToDelete">
                            </form>
                        </td>                                    
                    </tr>
                            <?php     
                                    }
                                }
                            ?>
                    </table>
                </div>
                <div class="col-3"></div>
          </div>
        </div>
      

    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../../js/jquery-3.3.1.min.js"></script>
  <script src="../../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../../js/jquery-ui.js"></script>
  <script src="../../js/popper.min.js"></script>
  <script src="../../js/bootstrap.min.js"></script>
  <script src="../../js/owl.carousel.min.js"></script>
  <script src="../../js/jquery.stellar.min.js"></script>
  <script src="../../js/jquery.countdown.min.js"></script>
  <script src="../../js/bootstrap-datepicker.min.js"></script>
  <script src="../../js/jquery.easing.1.3.js"></script>
  <script src="../../js/aos.js"></script>
  <script src="../../js/jquery.fancybox.min.js"></script>
  <script src="../../js/jquery.sticky.js"></script>
  <script src="../../js/jquery.mb.YTPlayer.min.js"></script>



  <script src="../../js/main.js"></script>

</body>

</html>