<?php

// Include config file
require_once "../../dbconn.php";

// Define variables and initialize with empty values
$phone = $co_email = $location = $facebook = $instagram = $cakep_heading = $cakep_parag = $about_heading = $about_desc = "";
$phone_err = $co_email_err = $location_err = $facebook_err = $instagram_err = $cakep_heading_err = $cakep_parag_err = $about_heading_err = $about_desc_err = "";

// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
  // Get hidden input value
  $id = $_POST["id"];

//Validate fields are completed
$input_phone = trim($_POST["phone"]);
if(empty($input_phone)){
    $phone_err = "Please enter a phone number.";
} else{
    $phone = $input_phone;
}
$input_co_email = trim($_POST["co_email"]);
if(empty($input_co_email)){
    $co_email_err = "Please enter an email address.";
} else{
    $co_email = $input_co_email;
}
$input_location = trim($_POST["location"]);
if(empty($input_location)){
    $location_err = "Please enter your city location.";
} else{
    $location = $input_location;
}
$input_facebook = trim($_POST["facebook"]);
if(empty($input_facebook)){
    $facebook_err = "Please enter the facebook URL.";
} else{
    $facebook = $input_facebook;
}
$input_instagram = trim($_POST["instagram"]);
if(empty($input_instagram)){
    $instagram_err = "Please enter the instagram URL.";
} else{
    $instagram = $input_instagram;
}
$input_cakep_heading = trim($_POST["cakep_heading"]);
if(empty($input_cakep_heading)){
    $cakep_heading_err = "Please enter the Cake Page heading.";
} else{
    $cakep_heading = $input_cakep_heading;
}
$input_cakep_parag = trim($_POST["cakep_parag"]);
if(empty($input_cakep_parag)){
    $cakep_parag_err = "Please enter the Cake Page paragraph.";
} else{
    $cakep_parag = $input_cakep_parag;
}
$input_about_heading = trim($_POST["about_heading"]);
if(empty($input_about_heading)){
    $about_heading_err = "Please enter the About Page heading.";
} else{
    $about_heading = $input_about_heading;
}
$input_about_desc = trim($_POST["about_desc"]);
if(empty($input_about_desc)){
    $about_desc_err = "Please enter the About Page blurb.";
} else{
    $about_desc = $input_about_desc;
}

// Check input errors before inserting in database
if(empty($phone_err) && empty($co_email_err) && empty($location_err) && empty($facebook_err) && empty($instagram_err) && empty($cakep_heading_err) && empty($cakep_parag_err) && empty($about_heading_err) && empty($about_desc_err)){
  // Prepare an update statement
  $sql = "UPDATE co_info SET phone=?, co_email=?, location=?, facebook=?, instagram=?, cakep_heading=?, cakep_parag=?, about_heading=?, about_desc=?";

  if($stmt = mysqli_prepare($link, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "sssssssss", $param_phone, $param_co_email, $param_location, $param_facebook, $param_instagram, $param_cakep_heading, $param_cakep_parag, $param_about_heading, $param_about_desc);

      $param_phone = $phone;
      $param_co_email = $co_email;
      $param_location = $location;
      $param_facebook = $facebook;
      $param_instagram = $instagram;
      $param_cakep_heading = $cakep_heading;
      $param_cakep_parag = $cakep_parag;
      $param_about_heading = $about_heading;
      $param_about_desc = $about_desc;
          
      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
          // Records updated successfully. Redirect to landing page
          header("location: a_cakes.php");
          exit();
      } else{
          echo "Something went wrong. Please try again later.";
      }
  }
  
  // Close statement
  mysqli_stmt_close($stmt);
}

// Close connection
mysqli_close($link);

} else{

  // Check existence of id parameter before processing further
  if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
      // Get URL parameter
      $id =  trim($_GET["id"]);
      
      // Prepare a select statement
      $sql = "SELECT * FROM co_info WHERE info_id = ?";
      if($stmt = mysqli_prepare($link, $sql)){
          // Bind variables to the prepared statement as parameters
          mysqli_stmt_bind_param($stmt, "i", $param_info_id);
          
          // Set parameters
          $param_info_id = $id;

          
          // Attempt to execute the prepared statement
          if(mysqli_stmt_execute($stmt)){
              $result = mysqli_stmt_get_result($stmt);
  
              if(mysqli_num_rows($result) == 1){
                  /* Fetch result row as an associative array. Since the result set
                  contains only one row, we don't need to use while loop */
                  $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                  
                    // Retrieve individual field value
                    $phone = $row["phone"];
                    $co_email = $row["co_email"];
                    $location = $row["location"];
                    $facebook = $row["facebook"];
                    $instagram = $row["instagram"];
                    $cakep_heading = $row["cakep_heading"];
                    $cakep_parag = $row["cakep_parag"];
                    $about_heading = $row["about_heading"];
                    $about_desc = $row["about_desc"];
              } else{
                  // URL doesn't contain valid id. Redirect to error page
                  header("location: admin_error.php");
                  exit();
              }
              
          } else{
              echo "Oops! Something went wrong. Please try again later.";
          }
      }
      
      // Close statement
      mysqli_stmt_close($stmt);
      
      // Close connection
      mysqli_close($link);
  }  else{
      // URL doesn't contain id parameter. Redirect to error page         
      header("location: admin_error.php");

      exit();
  }
}
?>

 


<!DOCTYPE html>
<html lang="en">

<head>
  <title>Admin Company Info</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
 <!-- <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">-->

  <link rel="stylesheet" href="../../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/jquery-ui.css">
  <link rel="stylesheet" href="../../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../../css/style.css">


</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
<header class="site-navbar site-navbar-target" role="banner">

<div class="container">
    <div class="row align-items-center position-relative">

      <div class="col-lg-5">
        <nav class="site-navigation text-right ml-auto" role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li><a href="a_cakes.php" class="nav-link">Cakes</a></li>
            <li><a href="testim.php" class="nav-link">Testimonials</a></li>
          </ul>
        </nav>
      </div>

      <div class="col-lg-2 text-center">
        <div class="site-logo">
          <a href="../index.php" class="site-logo">
            <img src="../../images/logo.png" alt="Image" class="img-fluid">
          </a>
        </div>
      </div>

      <div class="col-lg-5">
        <nav class="site-navigation text-left mr-auto " role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li class="active"><a href="coinfo.php" class="nav-link">Company Info</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="logout.php" type="submit" class="btn btn-warning" style="width: 100px">Logout</a></li>
          </ul>
        </nav>
      </div>
      
      <div class="ml-auto py-md-3 px-md-3 py-sm-3 px-sm-4 toggle-button d-inline-block d-lg-none">
        <a href="#" class="site-menu-toggle js-menu-toggle text-black">
        <span class="icon-menu" style="font-size:80px;"></span></a>
          </div>
          
    </div>
  </div>

</header>

    <div class="admin container">
            
            
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                <?php
                session_start();
                // check if the user logged in is admin
                if(isset($_SESSION["loggedin"]) === true){
                ?>
                <br>
                <h2 style="text-align:center">Update Penny Pickles Information</h2></div>
                <?php
                }
                else {
                  //Redirect to login page
                  header("location: ../index.php");
                }
                ?>
                <div class="col-lg-2"></div>
            </div>
          <br>
          <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                    <table class="table table-borderless">
                      <tr>
                        <div class="form-group <?php echo (!empty($phone_err)) ? 'has-error' : ''; ?>">
                        <td width="20%"><label>Phone</label></td>
                        <td width="80%"><input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>">
                            <span class="help-block"><?php echo $phone_err;?></span></td>
                        </div>
                      </tr>
                      <tr>
                        <div class="form-group <?php echo (!empty($co_email_err)) ? 'has-error' : ''; ?>">
                            <td><label>Email</label></td>
                            <td><input type="text" name="co_email" class="form-control" value="<?php echo $co_email; ?>">
                            <span class="help-block"><?php echo $co_email_err;?></span>
                        </div>
                      </tr>
                      <tr>
                        <div class="form-group <?php echo (!empty($location_err)) ? 'has-error' : ''; ?>">
                        <td><label>Location</label></td>
                        <td><input type="text" name="location" class="form-control" value="<?php echo $location; ?>">
                            <span class="help-block"><?php echo $location_err;?></span></td>
                        </div>
                      </tr>
                      <tr>
                        <div class="form-group <?php echo (!empty($facebook_err)) ? 'has-error' : ''; ?>">
                        <td><label>Facebook URL</label></td>
                        <td><input type="text" name="facebook" class="form-control" value="<?php echo $facebook; ?>">
                            <span class="help-block"><?php echo $facebook_err;?></span></td>
                        </div>
                      </tr>
                      <tr>
                        <div class="form-group <?php echo (!empty($instagram_err)) ? 'has-error' : ''; ?>">
                        <td><label>Instagram URL</label></td>
                        <td><input type="text" name="instagram" class="form-control" value="<?php echo $instagram; ?>">
                            <span class="help-block"><?php echo $instagram_err;?></span></td>
                        </div>
                        </tr>
                        <tr>
                        <td><label style="font-weight:bold">Cake Page</label></td>
                        </tr>
                        <tr>
                        <div class="form-group <?php echo (!empty($cakep_heading_err)) ? 'has-error' : ''; ?>">
                        <td><label>Heading</label></td>
                        <td><input type="text" name="cakep_heading" class="form-control" value="<?php echo $cakep_heading; ?>">
                            <span class="help-block"><?php echo $cakep_heading_err;?></span></td>
                        </div>
                        </tr>
                        <tr>
                        <div class="form-group <?php echo (!empty($cakep_parag_err)) ? 'has-error' : ''; ?>">
                        <td><label>Description</label></td>
                        <td><textarea name="cakep_parag" rows="6" class="form-control"><?php echo $cakep_parag; ?></textarea>
                            <span class="help-block"><?php echo $cakep_parag_err;?></span></td>
                        </div>
                        </tr>
                        <tr>
                        <td><label style="font-weight:bold">About Page</label></td>
                        </tr>
                        <tr>
                        <div class="form-group <?php echo (!empty($about_heading_err)) ? 'has-error' : ''; ?>">
                        <td><label>Heading</label></td>
                        <td><input type="text" name="about_heading" class="form-control" value="<?php echo $about_heading; ?>">
                            <span class="help-block"><?php echo $about_heading_err;?></span></td>
                        </div>
                        </tr>
                        <tr>
                        <div class="form-group <?php echo (!empty($about_desc_err)) ? 'has-error' : ''; ?>">
                        <td><label>Description</label></td>
                        <td><textarea name="about_desc" rows="6" class="form-control"><?php echo $about_desc; ?></textarea>
                            <span class="help-block"><?php echo $about_desc_err;?></span></td>
                        </div>
                        </tr>
                        </table>
                        <br>
                        <div class="row">
                            <div class="col-2"></div>
                            <div class="col-4">
                            <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                            <input type="submit" class="btn btn-success" style="float:right; width:200px" value="Update"></div>
                            <div class="col-6"><a href="../index.php" class="btn btn-warning" style="float:right; width:200px" >Cancel</a>
                            </div>
                        </div>
                    </form>
                    <br>
                </div>
                <div class="col-lg-2"></div>
            </div>
        </div>
            
    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../../js/jquery-3.3.1.min.js"></script>
  <script src="../../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../../js/jquery-ui.js"></script>
  <script src="../../js/popper.min.js"></script>
  <script src="../../js/bootstrap.min.js"></script>
  <script src="../../js/owl.carousel.min.js"></script>
  <script src="../../js/jquery.stellar.min.js"></script>
  <script src="../../js/jquery.countdown.min.js"></script>
  <script src="../../js/bootstrap-datepicker.min.js"></script>
  <script src="../../js/jquery.easing.1.3.js"></script>
  <script src="../../js/aos.js"></script>
  <script src="../../js/jquery.fancybox.min.js"></script>
  <script src="../../js/jquery.sticky.js"></script>
  <script src="../../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../../js/main.js"></script>

</body>

</html>