<?php


// Include config file
require_once "../../dbconn.php";


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Admin Testimonials</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
 <!-- <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">-->

  <link rel="stylesheet" href="../../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/jquery-ui.css">
  <link rel="stylesheet" href="../../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../../css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
<header class="site-navbar site-navbar-target" role="banner">

<div class="container">
    <div class="row align-items-center position-relative">

      <div class="col-lg-5">
        <nav class="site-navigation text-right ml-auto" role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li><a href="a_cakes.php" class="nav-link">Cakes</a></li>
            <li class="active"><a href="testim.php" class="nav-link">Testimonials</a></li>
          </ul>
        </nav>
      </div>

      <div class="col-lg-2 text-center">
        <div class="site-logo">
          <a href="../index.php" class="site-logo">
            <img src="../../images/logo.png" alt="Image" class="img-fluid">
          </a>
        </div>
      </div>

      <div class="col-lg-5">
        <nav class="site-navigation text-left mr-auto " role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li><a href="coinfo.php?id=1" class="nav-link">Company Info</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="logout.php" type="submit" class="btn btn-warning" style="width: 100px">Logout</a></li>
          </ul>
        </nav>
      </div>
      
      <div class="ml-auto py-md-3 px-md-3 py-sm-3 px-sm-4 toggle-button d-inline-block d-lg-none">
        <a href="#" class="site-menu-toggle js-menu-toggle text-black">
        <span class="icon-menu" style="font-size:80px;"></span></a>
          </div>

    </div>
  </div>

</header>

    <div class="admin container">
            
            
              <div class="row admin-p" style="padding-top:20px">
                <div class="col-1"></div>
                <div class="col-8">
                <?php
                session_start();
                // check if the user logged in is admin
                if(isset($_SESSION["loggedin"]) === true){
                ?>
                <h2>Manage Testimonials</h2></div>
                <?php
                }
                else {
                  //Redirect to login page
                  header("location: ../index.php");
                }
                ?>
                <div class="col-2">
                <a href="testim_create.php" class="btn btn-success" style="float:right">+ New Testimonial</a>
                </div>
                <div class="col-1"></div>
            </div>
          <br>
          <div class="row">
                <div class="col-1"></div>
                <div class="col-10">
                    <?php  
                    // Attempt select query execution
                    $sql = "SELECT * FROM testimonial";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo "<table class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                                echo "<th>Ref #</th>";
                                                echo "<th>Name</th>";
                                                echo "<th>Description</th>";
                                                echo "<th>Action</th>";
                                            echo "</tr>";
                                        echo "</thead>";
                                        echo "<tbody>";
                                        while($row = mysqli_fetch_array($result)){
                                            echo "<tr>";
                                                echo "<td>" . $row['test_id'] . "</td>";
                                                echo "<td>" . $row['test_name'] . "</td>";
                                                echo "<td>" . $row['test_desc'] . "</td>";
                                                echo "<td>";
                                                    echo "&nbsp&nbsp<a href='testim_delete.php?id=". $row['test_id'] ."' title='Delete Record' data-toggle='tooltip' style='color:#000000;font-size:1.2em'><span class='icon-trash'></span></a>";
                                                echo "</td>";
                                            echo "</tr>";
                                        }
                                        echo "</tbody>";                            
                                    echo "</table>";
                                    // Free result set
                                    mysqli_free_result($result);
                                } else{
                                    echo "<p class='lead'><em>No records were found.</em></p>";
                                }
                            } else{
                                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                            }

                            // Close connection
                            mysqli_close($link);
                            ?>
                                            </div>
                            <div class="col-1"></div>
                        </div>
                        </div>
                              
    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../../js/jquery-3.3.1.min.js"></script>
  <script src="../../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../../js/jquery-ui.js"></script>
  <script src="../../js/popper.min.js"></script>
  <script src="../../js/bootstrap.min.js"></script>
  <script src="../../js/owl.carousel.min.js"></script>
  <script src="../../js/jquery.stellar.min.js"></script>
  <script src="../../js/jquery.countdown.min.js"></script>
  <script src="../../js/bootstrap-datepicker.min.js"></script>
  <script src="../../js/jquery.easing.1.3.js"></script>
  <script src="../../js/aos.js"></script>
  <script src="../../js/jquery.fancybox.min.js"></script>
  <script src="../../js/jquery.sticky.js"></script>
  <script src="../../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../../js/main.js"></script>

</body>

</html>