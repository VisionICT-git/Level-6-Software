<?php

// Include config file
require_once "../../dbconn.php";

// Define variables and initialize with empty values
$cake_id = $cat_id = $category = $cake_name = $cake_desc = $flavours = $icing = "";
$cake_name_err = $cake_desc_err = $flavours_err = $icing_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate that each of the free text entry fields are populated
        $input_cake_name = trim($_POST["cake_name"]);
        if(empty($input_cake_name)){
            $cake_name_err = "Please enter the cake name.";     
        } else{
            $cake_name = $input_cake_name;
        }
        $input_cake_desc = trim($_POST["cake_desc"]);
        if(empty($input_cake_desc)){
            $cake_desc_err = "Please enter a description of the cake.";     
        } else{
            $cake_desc = $input_cake_desc;
        }
        $input_flavours = trim($_POST["flavours"]);
        if(empty($input_flavours)){
            $flavours_err = "Please enter the flavours for the cake.";     
        } else{
            $flavours = $input_flavours;
        }
        $input_icing = trim($_POST["icing"]);
        if(empty($input_icing)){
            $icing_err = "Please enter the icing for the cake.";     
        } else{
            $icing = $input_icing;
        }

// Check input errors before inserting in database
if(empty($cat_id_err) && empty($cake_name_err) && empty($cake_desc_err) && empty($flavours_err) && empty($icing_err)){
    // Prepare the insert statement
    $sql = "INSERT INTO cake_info (cat_id, cake_name, cake_desc, flavours, icing) VALUES (?,?,?,?,?);";
            
        if($stmt = mysqli_prepare($link, $sql)){
                       
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "issss", $param_cat_id, $param_cake_name, $param_cake_desc, $param_flavours, $param_icing); 
            
            $param_cat_id = $_POST['cat_id'];
            $param_cake_name = $cake_name;
            $param_cake_desc = $cake_desc;
            $param_flavours = $flavours;
            $param_icing = $icing;

            //define values selected from drop down lists and checkbox
            //$param_cat_id = $_POST['cat_id'];
            //$param_test_desc = $_POST['test_desc'];

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
              $last_id = mysqli_insert_id($link);
                // Records created successfully. Redirect to landing page
                header("location: cake_images.php?id=".$last_id);
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <title>Add Cake</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
 <!-- <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">-->

  <link rel="stylesheet" href="../../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/jquery-ui.css">
  <link rel="stylesheet" href="../../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../../css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
<header class="site-navbar site-navbar-target" role="banner">

<div class="container">
    <div class="row align-items-center position-relative">

      <div class="col-lg-5">
        <nav class="site-navigation text-right ml-auto" role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li class="active"><a href="a_cakes.php" class="nav-link">Cakes</a></li>
            <li><a href="testim.php" class="nav-link">Testimonials</a></li>
          </ul>
        </nav>
        
      </div>
      <div class="col-lg-2 text-center">
        <div class="site-logo">
          <a href="../index.php" class="site-logo">
            <img src="../../images/logo.png" alt="Image" class="img-fluid">
          </a>
        </div>
      </div>

      <div class="col-lg-5">
        <nav class="site-navigation text-left mr-auto " role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li><a href="coinfo.php?id=1" class="nav-link">Company Info</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="logout.php" type="submit" class="btn btn-warning" style="width: 100px">Logout</a></li>
          </ul>
        </nav>
      </div>
      
      <div class="ml-auto py-md-3 px-md-3 py-sm-3 px-sm-4 toggle-button d-inline-block d-lg-none">
        <a href="#" class="site-menu-toggle js-menu-toggle text-black">
        <span class="icon-menu" style="font-size:80px;"></span></a>
          </div>
          
    </div>
  </div>

</header>

    <div class="admin container">
      
            <div class="row admin-p" style="padding-top:20px">
                <div class="col-2"></div>
                <div class="col-6">
                <?php
                session_start();
                // check if the user logged in is admin
                if(isset($_SESSION["loggedin"]) === true){
                ?>
                <h2>Add a New Cake</h2></div>
                <?php
                }
                else {
                  //Redirect to login page
                  header("location: ../index.php");
                }
                ?>
                <div class="col-2">
                <a href="a_cakes.php" class="btn btn-warning" style="float:right">Back to List</a>
                </div>
                <div class="col-2"></div>
            </div>
          <br>
          <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
                    <table class="table table-borderless">
                    <tr>
                    <td width="20%">Category</td>
                    <td width="80%">
                    <?php
                        echo '<select name="cat_id" class="form-control" required>
                        <option value="">-- Select --</option>';
                        $sqli = "SELECT * FROM category_option";
                        $result = mysqli_query($link, $sqli);
                        while ($row = mysqli_fetch_array($result)){
                            echo '<option value="'.$row['cat_id'].'">'.$row['category'].' </option>';
                        }
                        echo '</select>';
                        ?>
                    </tr>
                    <tr>
                    <td>Name</td>
                    <td><input type="text" name="cake_name" class="form-control" <?php echo (!empty($cake_name_err)) ? 'has-error' : ''; ?> value="<?php echo $cake_name; ?>">
                        <span class="help-block"><?php echo $cake_name_err; ?></span></td>
                    </tr>
                    <tr>
                    <td>Desciption</td>
                    <td><textarea name="cake_desc" rows="4" class="form-control" <?php echo (!empty($cake_desc_err)) ? 'has-error' : ''; ?> value="<?php echo $cake_desc; ?>"></textarea>
                        <span class="help-block"><?php echo $cake_desc_err; ?></span></td>
                    </tr>
                    <tr>
                    <td>Flavours</td>
                    <td><textarea name="flavours" rows="2" class="form-control" <?php echo (!empty($flavours_err)) ? 'has-error' : ''; ?> value="<?php echo $flavours; ?>"></textarea>
                        <span class="help-block"><?php echo $flavours_err; ?></span></td>
                    </tr>
                    <tr>
                    <td>Icing</td>
                    <td><input type="text" name="icing" class="form-control" <?php echo (!empty($icing_err)) ? 'has-error' : ''; ?> value="<?php echo $icing; ?>">
                        <span class="help-block"><?php echo $icing_err; ?></span></td>
                    </tr>
                    </table>
                    <br>
                        <div class="row">
                            <div class="col-2"></div>
                            <div class="col-4">
                            <input type="submit" class="btn btn-success" id="checkBtn" style="float:right; width:200px" value="Add Cake">
                            </div>
                            <div class="col-6">
                            <a href="a_cakes.php" class="btn btn-warning" style="float:right; width:200px" >Cancel</a>
                            </div>
                        </div>
                    </form>
                <br>
                </div>
                <div class="col-2"></div>
          </div>
        </div>
      

    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../../js/jquery-3.3.1.min.js"></script>
  <script src="../../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../../js/jquery-ui.js"></script>
  <script src="../../js/popper.min.js"></script>
  <script src="../../js/bootstrap.min.js"></script>
  <script src="../../js/owl.carousel.min.js"></script>
  <script src="../../js/jquery.stellar.min.js"></script>
  <script src="../../js/jquery.countdown.min.js"></script>
  <script src="../../js/bootstrap-datepicker.min.js"></script>
  <script src="../../js/jquery.easing.1.3.js"></script>
  <script src="../../js/aos.js"></script>
  <script src="../../js/jquery.fancybox.min.js"></script>
  <script src="../../js/jquery.sticky.js"></script>
  <script src="../../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../../js/main.js"></script>

</body>

</html>