<?php
// Process delete operation after confirmation
if(isset($_POST["test_id"]) && !empty($_POST["test_id"])){
    // Include config file
    require_once "../../dbconn.php";
    
    // Prepare a delete statement
    $sql = "DELETE FROM testimonial WHERE test_id = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_test_id);
        
        // Set parameters
        $param_test_id = trim($_POST["test_id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Records deleted successfully. Redirect to landing page
            header("location: testim.php");
            exit();
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter
    if(empty(trim($_GET["id"]))){
        // URL doesn't contain id parameter. Redirect to error page
        header("location: admin_error.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Record</title>
    
    <!-- Css Styles -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="page-header">
                        <?php
                            session_start();
                            // check if the user logged in is admin
                            if(isset($_SESSION["loggedin"]) === true){
                        ?>
                        <h1>Delete Testimonial Record</h1>
                        <?php
                            }
                            else {
                            //Redirect to login page
                            header("location: ../index.php");
                            }
                        ?>
                    </div>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                        <div class="alert alert-danger fade in">
                            <input type="hidden" name="test_id" value="<?php echo trim($_GET["id"]); ?>"/>
                            <p>Are you sure you want to delete this record?</p><br>
                            <p>
                                <input type="submit" value="Yes" class="btn btn-danger">
                                <a href="testim.php" class="btn btn-default">No</a>
                            </p>
                        </div>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>        
        </div>
    </div>
</body>
</html>