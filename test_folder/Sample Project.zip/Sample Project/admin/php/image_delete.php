<?php

// Include config file
require_once "../../dbconn.php";

// Initialize the session
session_start();

$cake_id = $_GET['id'];
$img_name = $_GET['imageid'];

if (array_key_exists('delete_file', $_POST)) {
    $path = "images";
    $filename =  $_POST['delete_file'];
            unlink("../../images/".$filename);
            echo 'File ' . $filename . ' has been deleted.';

            $target_dir = "../../images/";

            $sql = "DELETE FROM images WHERE img_name = ('$img_name')";

                if (mysqli_query($link, $sql)) {
                echo " Record deleted successfully.";
                header("location: cake_images.php?id=$cake_id");
                } else {
                echo "Error deleting record: " . mysqli_error($link);
                }
}
    
mysqli_close($link);
?>

