<?php
// Include config file
require_once "../dbconn.php";

// Source: code for contact form based on https://supunkavinda.blog/php/contact-form
$name = $phone = $email = $date = $message = "";
$name_err = $email_err = $message_err = "";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
  // Validate that the required fields are populated
  if (empty($_POST['name'])) {
		$name_err = 'Please enter your name';
	} else {
		$name = $_POST['name'];
  }
	if (empty($_POST['useremail'])) {
		$email_err = 'Please enter your email address';
	} else {
		$email = $_POST['useremail'];

		// validating the email
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$email_err = 'Invalid email';
		}
	}
	if (empty($_POST['message'])) {
		$message_err = 'Please enter a message';
	} else {
		$message = $_POST['message'];
	}
	if (empty($name_err) &&empty($email_err) && empty($message_err)) {
		$date = date('j, F Y');
		$phone = $_POST['phone'];
		
		
		$emailBody = "
			<html>
			<head>
				<title>$email is Message from Penny Pickles Cakes</title>
			</head>
			<body style=\"background-color:#fafafa;\">
				<div style=\"padding:20px;\">
					Date: <span style=\"color:#888\">$date</span>
					<br><br>
					Sender: <span style=\"color:#888\">$name</span>
					<br>
					Phone: <span style=\"color:#888\">$phone</span>
					<br>
					Email: <span style=\"color:#888\">$email</span>
					<br><br>
					Message: <div style=\"color:#888\">$message
          			</div>
				</div>
			</body>
			</html>
		";

		$headers = 	'From: Contact Form <contact@pennypicklescakes.co.nz>' . "\r\n" .
    				"Reply-To: $email" . "\r\n" .
    				"MIME-Version: 1.0\r\n" . 
					"Content-Type: text/html; charset=iso-8859-1\r\n";

		$to = 'ruthop13@gmail.com';
		$subject = 'Message from Penny Pickles Cakes';

		if (mail($to, $subject, $emailBody, $headers)) {
			$sent = true;	
			header("location: msg_sent.php");
              
    }
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Contact</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
 <!-- <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">-->

  <link rel="stylesheet" href="../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/jquery-ui.css">
  <link rel="stylesheet" href="../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../css/style.css">
  <style>
.help-block{
  color:red;
}
</style>

</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
<header class="site-navbar site-navbar-target" role="banner">

<div class="container">
  <div class="row align-items-center position-relative">

    <div class="col-lg-5">
      <nav class="site-navigation text-right ml-auto " role="navigation">
        <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
          <li><a href="../index.php" class="nav-link">Home</a></li>
          <li><a href="cakes.php" class="nav-link">Cakes</a></li>
        </ul>
      </nav>
    </div>
    
    <div class="col-lg-2 text-center">
      <div class="site-logo">
        <a href="../index.php" class="site-logo">
          <img src="../images/logo.png" alt="Image" class="img-fluid">
        </a>
      </div>
    </div>

    <div class="col-lg-5">
      <nav class="site-navigation text-left mr-auto " role="navigation">
        <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
          <li><a href="about.php" class="nav-link">About</a></li>
          <li class="active"><a href="contact.php" class="nav-link">Contact</a></li>

        </ul>
      </nav>
    </div>
    
    <div class="ml-auto py-md-3 px-md-3 py-sm-3 px-sm-4 toggle-button d-inline-block d-lg-none">
        <a href="#" class="site-menu-toggle js-menu-toggle text-black">
        <span class="icon-menu" style="font-size:50px;"></span></a>
          </div>

  </div>
</div>

</header>
<div class="about-contact container">
    <div class="site-section py-5 custom-border-bottom" data-aos="fade">
      <div class="container">
        <div class="row mb-5">
        <div class="col-md-2"></div>
          <div class="col-md-8">
            <h2 style="text-align:center">Get in Touch</h2>
            <br>
            <form method="POST" class="row">
              <div class="form-group col-md-6">
                <input type="text" class="form-control" <?php echo (!empty($name_err)) ? 'has-error' : ''; ?> placeholder="Your Name" name="name">
                <span class="help-block"><?php echo $name_err; ?></span>
              </div>
              <div class="form-group col-md-6">
                <input type="text" class="form-control" placeholder="Phone Number" name="phone">
              </div>
              <div class="form-group col-md-6">
                <input type="text" class="form-control" <?php echo (!empty($email_err)) ? 'has-error' : ''; ?> placeholder="Your Email" name="useremail">
                <span class="help-block"><?php echo $email_err; ?></span>
              </div>
              <div class="col-md-6"></div>
				
              <div class="form-group col-md-12">
				  <br>
                <textarea  name="message" cols="30" rows="4" class="form-control"<?php echo (!empty($message_err)) ? 'has-error' : ''; ?> placeholder="Your Message..."></textarea>
                <span class="help-block"><?php echo $message_err; ?></span>
              </div>
              
              <div class="form-group col-md-12" style="text-align:center; padding-top:10px">
                <input type="submit" class="btn btn-warning" value="Send Message">
              </div>
            </form>

			  <div class="col-md-2"></div>
          </div>
        </div>
      </div>
    </div>
</div>


    <div class="footer">
      <div class="container">
        
      <?php include 'footer.php';
          mysqli_close($link);?>

      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../js/jquery-3.3.1.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/jquery.countdown.min.js"></script>
  <script src="../js/bootstrap-datepicker.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.fancybox.min.js"></script>
  <script src="../js/jquery.sticky.js"></script>
  <script src="../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../js/main.js"></script>

</body>

</html>