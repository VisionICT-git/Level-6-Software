      
        <div class="row">
          <div class="col-md-3"></div>
          <div class="col-md-6 text-center">
            <?php
            $sql = "SELECT * FROM co_info";
            $result = mysqli_query($link, $sql);
            $row = mysqli_fetch_array($result);
            ?>
            <p><?php echo $row['co_email'];?><br>
            <?php echo $row['location'];?></p>
            <p>&copy;All Rights Reserved</p>
          </div>
          <div class="col-md-3 text-center">
          <p>FOLLOW US</p>
            <div class="social-icons">
            <a href="<?php echo $row['facebook'];?>" target="_blank" style="background:blue"><span class="icon-facebook"></span></a>&nbsp&nbsp
              <a href="<?php echo $row['instagram'];?>" target="_blank" style="background: linear-gradient(to top right, yellow, red , purple);"><span class="icon-instagram"></span></a>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
            </div>
          </div>
        </div>