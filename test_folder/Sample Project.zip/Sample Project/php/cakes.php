<?php
// Include config file
require_once "../dbconn.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Cakes</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
 <!-- <link href="https://fonts.googleapis.com/css?family=Cinzel:400,700|Montserrat:400,700|Roboto&display=swap" rel="stylesheet">-->

  <link rel="stylesheet" href="../fonts/icomoon/style.css">

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/jquery-ui.css">
  <link rel="stylesheet" href="../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">
  <link rel="stylesheet" href="../css/owl.theme.default.min.css">

  <link rel="stylesheet" href="../css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="../css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="../fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="../css/aos.css">
  <link href="../css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="../css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    
<header class="site-navbar site-navbar-target" role="banner">

<div class="container">
  <div class="row align-items-center position-relative">

    <div class="col-lg-5">
      <nav class="site-navigation text-right ml-auto " role="navigation">
        <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
          <li><a href="../index.php" class="nav-link">Home</a></li>
          <li class="active"><a href="cakes.php" class="nav-link">Cakes</a></li>
        </ul>
      </nav>
    </div>
    
    <div class="col-lg-2 text-center">
      <div class="site-logo">
        <a href="../index.php" class="site-logo">
          <img src="../images/logo.png" alt="Image" class="img-fluid">
        </a>
      </div>    
    </div>

    <div class="col-lg-5">
      <nav class="site-navigation text-left mr-auto " role="navigation">
        <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
          <li><a href="about.php" class="nav-link">About</a></li>
          <li><a href="contact.php" class="nav-link">Contact</a></li>

        </ul>
      </nav>
    </div>
    <div class="ml-auto py-md-3 px-md-3 py-sm-3 px-sm-4 toggle-button d-inline-block d-lg-none">
        <a href="#" class="site-menu-toggle js-menu-toggle text-black">
        <span class="icon-menu" style="font-size:50px;"></span></a>
          </div>

  </div>
</div>

</header>
<div class="about-contact container">
    <div class="site-section py-5 custom-border-bottom" data-aos="fade">
      <div class="container cakes">
        <div class="row mb-5">
          <div class="col-md-1"></div>
          <div class="col-md-10">
              <?php
              $sql = "SELECT * FROM co_info";
              $result = mysqli_query($link, $sql);
              $row = mysqli_fetch_array($result);{
              ?>
              <h2><?php echo $row['cakep_heading'];?></h2><br>
              <p><?php echo $row['cakep_parag'];}?></p><br>
            <div class="row">
            <div class="col-md-4">
              <a href="cake_category.php?id=1"><img src="../images/wed_c.jpg" alt="wedding" class="img-fluid"></a>
              <h5>Weddings</h5>
              </div>
              <div class="col-md-4">
              <a href="cake_category.php?id=2"><img src="../images/bday_c.jpg" alt="birthday" class="img-fluid"></a>
              <h5>Birthdays</h5>
              </div>
              <div class="col-md-4">
              <a href="cake_category.php?id=3"><img src="../images/spec_c.jpg" alt="special occasion" class="img-fluid"></a>
              <h5>Special Occasions</h5>
              </div>
            </div>
          <div class="col-md-1"></div>
          </div>
        </div>
      </div>
    </div>
</div>
   
    
    <div class="footer">
      <div class="container">
      <?php include 'footer.php';
          mysqli_close($link);?>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="../js/jquery-3.3.1.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/jquery.countdown.min.js"></script>
  <script src="../js/bootstrap-datepicker.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.fancybox.min.js"></script>
  <script src="../js/jquery.sticky.js"></script>
  <script src="../js/jquery.mb.YTPlayer.min.js"></script>




  <script src="../js/main.js"></script>

</body>

</html>